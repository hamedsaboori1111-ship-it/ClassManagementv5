package com.example.util

import java.util.Calendar

object DateUtils {

    val PERSIAN_MONTH_NAMES = arrayOf(
        "فروردین", "اردیبهشت", "خرداد",
        "تیر", "مرداد", "شهریور",
        "مهر", "آبان", "آذر",
        "دی", "بهمن", "اسفند"
    )

    fun getMonthName(month: Int): String {
        return if (month in 1..12) PERSIAN_MONTH_NAMES[month - 1] else ""
    }

    fun isLeapJalaliYear(year: Int): Boolean {
        // Algorithm for Jalali leap year
        val a = year - 474
        val b = (a % 2820) + 474
        val leapMod = ((b + 38) * 682) % 2816
        return leapMod < 682
    }

    fun getDaysInMonth(year: Int, month: Int): Int {
        return when (month) {
            in 1..6 -> 31
            in 7..11 -> 30
            12 -> if (isLeapJalaliYear(year)) 30 else 29
            else -> 30
        }
    }

    fun parseJalali(dateStr: String): JalaliDate? {
        try {
            val eng = toEnglishDigits(dateStr).trim()
            val parts = eng.split('/', '-', ' ', '.').filter { it.isNotBlank() }
            if (parts.size >= 3) {
                val y = parts[0].toIntOrNull() ?: return null
                val m = parts[1].toIntOrNull() ?: return null
                val d = parts[2].toIntOrNull() ?: return null
                if (m in 1..12 && d in 1..31) {
                    val (gy, gm, gd) = jalaliToGregorian(y, m, d)
                    val cal = Calendar.getInstance()
                    cal.set(gy, gm - 1, gd)
                    val dayName = when (cal.get(Calendar.DAY_OF_WEEK)) {
                        Calendar.SATURDAY -> "شنبه"
                        Calendar.SUNDAY -> "یکشنبه"
                        Calendar.MONDAY -> "دوشنبه"
                        Calendar.TUESDAY -> "سه‌شنبه"
                        Calendar.WEDNESDAY -> "چهارشنبه"
                        Calendar.THURSDAY -> "پنجشنبه"
                        Calendar.FRIDAY -> "جمعه"
                        else -> ""
                    }
                    return JalaliDate(
                        year = y,
                        month = m,
                        day = d,
                        dayOfWeekName = dayName,
                        monthName = getMonthName(m)
                    )
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
        return null
    }

    fun formatJalali(year: Int, month: Int, day: Int, persianDigits: Boolean = true): String {
        val y = year.toString()
        val m = month.toString().padStart(2, '0')
        val d = day.toString().padStart(2, '0')
        val res = "$y/$m/$d"
        return if (persianDigits) toPersianDigits(res) else res
    }

    /**
     * Extracts the Persian month name strictly from the student's birth date string.
     * Returns null if no birth date is registered, or if the date cannot be validated.
     */
    fun getStudentBirthMonth(birthDateStr: String?): String? {
        if (birthDateStr.isNullOrBlank()) return null
        val trimmed = birthDateStr.trim()
        if (trimmed.isEmpty() || trimmed == "ثبت نشده") return null

        val parsed = parseJalali(trimmed)
        if (parsed != null && parsed.month in 1..12) {
            return getMonthName(parsed.month)
        }

        val eng = toEnglishDigits(trimmed)
        val parts = eng.split('/', '-', ' ', '.', '_', '\\').filter { it.isNotBlank() }
        if (parts.size >= 2) {
            val p0 = parts[0].toIntOrNull()
            val p1 = parts[1].toIntOrNull()
            if (p0 != null && p0 > 1200 && p1 != null && p1 in 1..12) {
                return getMonthName(p1)
            }
            if (parts.size >= 3) {
                val p2 = parts[2].toIntOrNull()
                if (p2 != null && p2 > 1200 && p1 != null && p1 in 1..12) {
                    return getMonthName(p1)
                }
            }
        }

        for (i in 1..12) {
            val name = PERSIAN_MONTH_NAMES[i - 1]
            if (trimmed.contains(name)) {
                return name
            }
        }

        return null
    }

    /**
     * Checks with strict precision if a student's birth date falls in the specified target month.
     * Returns false if birth date is blank, missing, invalid, or belongs to a different month.
     */
    fun isBornInMonth(birthDateStr: String?, targetMonthName: String): Boolean {
        if (birthDateStr.isNullOrBlank() || targetMonthName.isBlank()) return false
        val birthMonth = getStudentBirthMonth(birthDateStr) ?: return false
        return birthMonth.trim() == targetMonthName.trim()
    }

    data class JalaliDate(
        val year: Int,
        val month: Int,
        val day: Int,
        val dayOfWeekName: String,
        val monthName: String
    ) {
        /**
         * Formats as Persian digits e.g. "۱۴۰۳/۰۷/۱۵"
         */
        fun toFormattedString(): String {
            val y = year.toString()
            val m = month.toString().padStart(2, '0')
            val d = day.toString().padStart(2, '0')
            return toPersianDigits("$y/$m/$d")
        }

        /**
         * Formats as full Persian string e.g. "شنبه ۲۱ شهریور ۱۴۰۵"
         */
        fun toFullDisplayString(): String {
            val d = toPersianDigits(day.toString())
            val y = toPersianDigits(year.toString())
            return "$dayOfWeekName $d $monthName $y"
        }
    }

    fun toPersianDigits(text: String): String {
        return text.map { char ->
            when (char) {
                '0' -> '۰'
                '1' -> '۱'
                '2' -> '۲'
                '3' -> '۳'
                '4' -> '۴'
                '5' -> '۵'
                '6' -> '۶'
                '7' -> '۷'
                '8' -> '۸'
                '9' -> '۹'
                else -> char
            }
        }.joinToString("")
    }

    fun toPersianDigits(number: Number): String {
        return toPersianDigits(number.toString())
    }

    fun toEnglishDigits(text: String): String {
        return text.map { char ->
            when (char) {
                '۰' -> '0'
                '۱' -> '1'
                '۲' -> '2'
                '۳' -> '3'
                '۴' -> '4'
                '۵' -> '5'
                '۶' -> '6'
                '۷' -> '7'
                '۸' -> '8'
                '۹' -> '9'
                else -> char
            }
        }.joinToString("")
    }

    /**
     * Converts Gregorian Year, Month (1-12), Day (1-31) to Jalali (Solar Hijri) date.
     * Uses the standard and precise astronomical conversion algorithm.
     */
    fun gregorianToJalali(gy: Int, gm: Int, gd: Int, dayOfWeekCalendarConstant: Int = -1): JalaliDate {
        val gDaysInMonth = intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        val jDaysInMonth = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)

        val gy2 = gy - 1600
        val gm2 = gm - 1
        val gd2 = gd - 1

        var gDayNo = 365 * gy2 + (gy2 + 3) / 4 - (gy2 + 99) / 100 + (gy2 + 399) / 400
        for (i in 0 until gm2) {
            gDayNo += gDaysInMonth[i]
        }
        if (gm2 > 1 && ((gy % 4 == 0 && gy % 100 != 0) || (gy % 400 == 0))) {
            gDayNo++
        }
        gDayNo += gd2

        var jDayNo = gDayNo - 79

        val jNp = jDayNo / 12053
        jDayNo %= 12053

        var jy = 979 + 33 * jNp + 4 * (jDayNo / 1461)
        jDayNo %= 1461

        if (jDayNo >= 366) {
            jy += (jDayNo - 1) / 365
            jDayNo = (jDayNo - 1) % 365
        }

        var jm = 0
        while (jm < 11 && jDayNo >= jDaysInMonth[jm]) {
            jDayNo -= jDaysInMonth[jm]
            jm++
        }
        val jd = jDayNo + 1
        val jMonth1Based = jm + 1

        val dayName = when (dayOfWeekCalendarConstant) {
            Calendar.SATURDAY -> "شنبه"
            Calendar.SUNDAY -> "یکشنبه"
            Calendar.MONDAY -> "دوشنبه"
            Calendar.TUESDAY -> "سه‌شنبه"
            Calendar.WEDNESDAY -> "چهارشنبه"
            Calendar.THURSDAY -> "پنجشنبه"
            Calendar.FRIDAY -> "جمعه"
            else -> ""
        }

        val monthName = if (jMonth1Based in 1..12) PERSIAN_MONTH_NAMES[jMonth1Based - 1] else ""

        return JalaliDate(
            year = jy,
            month = jMonth1Based,
            day = jd,
            dayOfWeekName = dayName,
            monthName = monthName
        )
    }

    /**
     * Gets the exact current Jalali date strictly based on the phone's current time.
     */
    fun getCurrentJalaliDate(): JalaliDate {
        val cal = Calendar.getInstance()
        val gy = cal.get(Calendar.YEAR)
        val gm = cal.get(Calendar.MONTH) + 1
        val gd = cal.get(Calendar.DAY_OF_MONTH)
        val dow = cal.get(Calendar.DAY_OF_WEEK)
        return gregorianToJalali(gy, gm, gd, dow)
    }

    /**
     * Returns the formatted Shamsi date (e.g. "۱۴۰۵/۰۶/۲۲") from the phone's clock.
     */
    fun getCurrentShamsiDate(): String {
        return getCurrentJalaliDate().toFormattedString()
    }

    /**
     * Returns the full Persian display text (e.g. "شنبه ۲۲ شهریور ۱۴۰۵") from the phone's clock.
     */
    fun getCurrentShamsiFullText(): String {
        return getCurrentJalaliDate().toFullDisplayString()
    }

    /**
     * Converts Jalali Year, Month (1-12), Day (1-31) to Gregorian date (Year, Month, Day).
     * Standard mathematical conversion algorithm.
     */
    fun jalaliToGregorian(jy: Int, jm: Int, jd: Int): Triple<Int, Int, Int> {
        val jy2 = jy - 979
        val jm2 = jm - 1
        val jd2 = jd - 1

        var jDayNo = 365 * jy2 + (jy2 / 33) * 8 + ((jy2 % 33 + 3) / 4)
        val jDaysInMonth = intArrayOf(31, 31, 31, 31, 31, 31, 30, 30, 30, 30, 30, 29)
        for (i in 0 until jm2) {
            jDayNo += jDaysInMonth[i]
        }
        jDayNo += jd2

        var gDayNo = jDayNo + 79

        var gy = 1600 + 400 * (gDayNo / 146097)
        gDayNo %= 146097

        var leap = true
        if (gDayNo >= 36525) {
            gDayNo--
            gy += 100 * (gDayNo / 36524)
            gDayNo %= 36524

            if (gDayNo >= 365) {
                gDayNo++
            } else {
                leap = false
            }
        }

        gy += 4 * (gDayNo / 1461)
        gDayNo %= 1461

        if (gDayNo >= 366) {
            leap = false
            gDayNo--
            gy += gDayNo / 365
            gDayNo %= 365
        }

        val gDaysInMonth = if (leap) {
            intArrayOf(31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        } else {
            intArrayOf(31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31)
        }

        var gm = 0
        while (gm < 12 && gDayNo >= gDaysInMonth[gm]) {
            gDayNo -= gDaysInMonth[gm]
            gm++
        }
        val gd = gDayNo + 1
        return Triple(gy, gm + 1, gd)
    }

    /**
     * Calculates the exact day of week (شنبه، یکشنبه، ... پنجشنبه، جمعه)
     * for any valid Shamsi date string (e.g. "۱۴۰۵/۰۷/۱۰" or "1405/07/10").
     */
    fun getDayOfWeekForShamsi(dateStr: String): String {
        val parsed = parseJalali(dateStr) ?: return getCurrentDayOfWeek()
        val (gy, gm, gd) = jalaliToGregorian(parsed.year, parsed.month, parsed.day)
        val cal = Calendar.getInstance()
        cal.set(gy, gm - 1, gd)
        return when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.SATURDAY -> "شنبه"
            Calendar.SUNDAY -> "یکشنبه"
            Calendar.MONDAY -> "دوشنبه"
            Calendar.TUESDAY -> "سه‌شنبه"
            Calendar.WEDNESDAY -> "چهارشنبه"
            Calendar.THURSDAY -> "پنجشنبه"
            Calendar.FRIDAY -> "جمعه"
            else -> "شنبه"
        }
    }

    /**
     * Returns true if the day is Thursday or Friday (weekend holiday).
     */
    fun isWeekendDay(dayName: String): Boolean {
        val trimmed = dayName.trim()
        return trimmed == "پنجشنبه" || trimmed == "جمعه"
    }

    /**
     * Returns today's day of week in Persian (شنبه تا جمعه).
     */
    fun getCurrentDayOfWeek(): String {
        val cal = Calendar.getInstance()
        return when (cal.get(Calendar.DAY_OF_WEEK)) {
            Calendar.SATURDAY -> "شنبه"
            Calendar.SUNDAY -> "یکشنبه"
            Calendar.MONDAY -> "دوشنبه"
            Calendar.TUESDAY -> "سه‌شنبه"
            Calendar.WEDNESDAY -> "چهارشنبه"
            Calendar.THURSDAY -> "پنجشنبه"
            Calendar.FRIDAY -> "جمعه"
            else -> "شنبه"
        }
    }
}
