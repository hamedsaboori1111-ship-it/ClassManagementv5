package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Student
import com.example.ui.components.StudentFormDialog
import com.example.ui.components.StudentProfileDetailDialog
import com.example.ui.theme.*
import com.example.util.DateUtils
import com.example.util.DemoConfig

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun StudentsListScreen(
    students: List<Student>,
    onBack: () -> Unit,
    onReorderStudents: (List<Student>) -> Unit,
    onAddStudent: (Student) -> Boolean,
    onUpdateStudent: (Student) -> Boolean,
    onDeleteStudent: (Long) -> Unit,
    onNavigateToPro: (() -> Unit)? = null
) {
    BackHandler { onBack() }
    val context = LocalContext.current

    // وضعیت‌های داخلی برای مدیریت دیالوگ‌ها
    var viewingStudent by remember { mutableStateOf<Student?>(null) }
    var editingStudent by remember { mutableStateOf<Student?>(null) }
    var showAddStudentDialog by remember { mutableStateOf(false) }
    var studentToDelete by remember { mutableStateOf<Student?>(null) }
    var showDemoLimitDialog by remember { mutableStateOf(false) }

    // جستجو در لیست دانش‌آموزان
    var searchQuery by remember { mutableStateOf("") }

    // نگهداری لیست مرتب‌شده جهت بازخورد سریع به کاربر
    var orderedList by remember(students) { mutableStateOf(students) }

    // تابع جابجایی دو عنصر در لیست و فراخوانی ذخیره آنی
    fun swapAndSave(fromIndex: Int, toIndex: Int) {
        if (fromIndex == toIndex || fromIndex !in orderedList.indices || toIndex !in orderedList.indices) return
        val mutable = orderedList.toMutableList()
        val item = mutable.removeAt(fromIndex)
        mutable.add(toIndex, item)
        orderedList = mutable
        onReorderStudents(mutable)
    }

    val filteredList = remember(orderedList, searchQuery) {
        if (searchQuery.isBlank()) {
            orderedList
        } else {
            val q = searchQuery.trim()
            orderedList.filter {
                it.name.contains(q, ignoreCase = true) ||
                it.shad.contains(q) ||
                it.fatherName.contains(q, ignoreCase = true)
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.PeopleAlt,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "لیست دانش‌آموزان",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.White.copy(alpha = 0.2f),
                        modifier = Modifier.padding(end = 8.dp)
                    ) {
                        Text(
                            text = "${DateUtils.toPersianDigits(orderedList.size)} دانش‌آموز",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryGreen)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = {
                    if (DemoConfig.isDemoActive(context) && orderedList.size >= DemoConfig.MAX_STUDENTS_COUNT) {
                        showDemoLimitDialog = true
                    } else {
                        editingStudent = null
                        showAddStudentDialog = true
                    }
                },
                containerColor = PrimaryGreen,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.PersonAdd, contentDescription = null) },
                text = { Text("افزودن دانش‌آموز", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("students_list_add_fab")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
        ) {
            // ۱. کادر راهنمای کاربر و فیلد جستجو
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color.White,
                shadowElevation = 1.dp
            ) {
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
                    // پیام راهنمای جابجایی ترتیب و ویرایش
                    Surface(
                        color = Color(0xFFF0FDF4),
                        border = BorderStroke(0.8.dp, Color(0xFFBBF7D0)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.SwapVert,
                                contentDescription = null,
                                tint = PrimaryGreenDark,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "برای جابجایی ترتیب، از دکمه‌های 🔼/🔽 یا نگه داشتن و کشیدن استفاده کنید. ترتیب حضور و غیاب دقیقاً مطابق این لیست خواهد بود.",
                                fontSize = 11.sp,
                                color = PrimaryGreenDark,
                                lineHeight = 16.sp
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // فیلد جستجو
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp),
                        placeholder = { Text("جستجو بر اساس نام، شاد یا نام پدر...", fontSize = 12.sp) },
                        leadingIcon = {
                            Icon(Icons.Default.Search, contentDescription = null, tint = TextSecondary, modifier = Modifier.size(20.dp))
                        },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "پاک کردن", modifier = Modifier.size(18.dp))
                                }
                            }
                        },
                        shape = RoundedCornerShape(10.dp),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = PrimaryGreen,
                            unfocusedBorderColor = BorderLight
                        )
                    )
                }
            }

            // ۲. لیست دانش‌آموزان
            if (filteredList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.PeopleOutline,
                            contentDescription = null,
                            tint = Color.LightGray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = if (searchQuery.isBlank()) "دانش‌آموزی در کلاس ثبت نشده است" else "هیچ دانش‌آموزی با این مشخصات یافت نشد",
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = if (searchQuery.isBlank()) "برای شروع، روی دکمه «افزودن دانش‌آموز» در پایین صفحه بزنید." else "عبارت جستجو را تغییر دهید.",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    itemsIndexed(filteredList, key = { _, s -> s.id }) { displayIndex, student ->
                        val actualIndex = orderedList.indexOfFirst { it.id == student.id }
                        val isFirst = actualIndex == 0
                        val isLast = actualIndex == orderedList.size - 1

                        var dragOffsetY by remember { mutableFloatStateOf(0f) }

                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(1.dp, BorderLight),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.5.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("student_item_${student.id}")
                                .clickable { viewingStudent = student }
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 10.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                // بخش سمت راست: دسته جابجایی و شماره ردیف و اطلاعات دانش‌آموز
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    // دسته نگه‌داشتن و کشیدن برای جابجایی
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(Color(0xFFF1F5F9))
                                            .pointerInput(student.id, orderedList) {
                                                detectDragGesturesAfterLongPress(
                                                    onDragStart = { dragOffsetY = 0f },
                                                    onDragEnd = { dragOffsetY = 0f },
                                                    onDragCancel = { dragOffsetY = 0f },
                                                    onDrag = { change, dragAmount ->
                                                        change.consume()
                                                        dragOffsetY += dragAmount.y
                                                        val threshold = 70f
                                                        if (dragOffsetY > threshold && actualIndex < orderedList.size - 1) {
                                                            swapAndSave(actualIndex, actualIndex + 1)
                                                            dragOffsetY = 0f
                                                        } else if (dragOffsetY < -threshold && actualIndex > 0) {
                                                            swapAndSave(actualIndex, actualIndex - 1)
                                                            dragOffsetY = 0f
                                                        }
                                                    }
                                                )
                                            },
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.DragHandle,
                                            contentDescription = "نگه داشتن برای جابجایی",
                                            tint = Color(0xFF64748B),
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    // نشانگر شماره ردیف در لیست کلاس
                                    Surface(
                                        shape = CircleShape,
                                        color = PrimaryGreen.copy(alpha = 0.12f),
                                        modifier = Modifier.size(26.dp)
                                    ) {
                                        Box(contentAlignment = Alignment.Center) {
                                            Text(
                                                text = DateUtils.toPersianDigits(actualIndex + 1),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.5.sp,
                                                color = PrimaryGreenDark
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(8.dp))

                                    // عکس دانش‌آموز یا آیکون با حرف اول نام
                                    if (student.photoUri.isNotBlank()) {
                                        AsyncImage(
                                            model = student.photoUri,
                                            contentDescription = "عکس ${student.name}",
                                            contentScale = ContentScale.Crop,
                                            modifier = Modifier
                                                .size(42.dp)
                                                .clip(CircleShape)
                                                .background(Color(0xFFE2E8F0))
                                        )
                                    } else {
                                        Box(
                                            modifier = Modifier
                                                .size(42.dp)
                                                .clip(CircleShape)
                                                .background(PrimaryGreen.copy(alpha = 0.15f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Text(
                                                text = student.name.take(1),
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 17.sp,
                                                color = PrimaryGreenDark
                                            )
                                        }
                                    }

                                    Spacer(modifier = Modifier.width(10.dp))

                                    // نام و مشخصات خلاصه دانش‌آموز
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = student.name,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 14.5.sp,
                                                color = TextPrimary
                                            )
                                        }
                                        Spacer(modifier = Modifier.height(2.dp))
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                text = "شاد: ${student.shad.ifBlank { "—" }}",
                                                fontSize = 11.sp,
                                                color = TextSecondary
                                            )
                                            if (student.fatherName.isNotBlank()) {
                                                Text(
                                                    text = " • پدر: ${student.fatherName}",
                                                    fontSize = 11.sp,
                                                    color = TextSecondary
                                                )
                                            }
                                        }
                                    }
                                }

                                // بخش سمت چپ: دکمه‌های جابجایی اختصاصی بالا/پایین و آیکون ویرایش
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    // دکمه انتقال به بالا
                                    IconButton(
                                        onClick = { swapAndSave(actualIndex, actualIndex - 1) },
                                        enabled = !isFirst && searchQuery.isBlank(),
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.KeyboardArrowUp,
                                            contentDescription = "انتقال به بالا",
                                            tint = if (!isFirst && searchQuery.isBlank()) PrimaryGreenDark else Color(0xFFCBD5E1),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    // دکمه انتقال به پایین
                                    IconButton(
                                        onClick = { swapAndSave(actualIndex, actualIndex + 1) },
                                        enabled = !isLast && searchQuery.isBlank(),
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.KeyboardArrowDown,
                                            contentDescription = "انتقال به پایین",
                                            tint = if (!isLast && searchQuery.isBlank()) PrimaryGreenDark else Color(0xFFCBD5E1),
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }

                                    // دکمه ویرایش سریع
                                    IconButton(
                                        onClick = {
                                            editingStudent = student
                                            showAddStudentDialog = true
                                        },
                                        modifier = Modifier.size(32.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Edit,
                                            contentDescription = "ویرایش اطلاعات دانش‌آموز",
                                            tint = Color(0xFF0284C7),
                                            modifier = Modifier.size(17.dp)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // دیالوگ مشاهده شناسنامه کامل دانش‌آموز
    viewingStudent?.let { student ->
        StudentProfileDetailDialog(
            student = student,
            onDismiss = { viewingStudent = null },
            onEdit = {
                viewingStudent = null
                editingStudent = student
                showAddStudentDialog = true
            },
            onDelete = {
                viewingStudent = null
                studentToDelete = student
            }
        )
    }

    // دیالوگ ثبت یا ویرایش اطلاعات دانش‌آموز
    if (showAddStudentDialog) {
        StudentFormDialog(
            initialStudent = editingStudent,
            existingStudents = orderedList,
            onDismiss = {
                showAddStudentDialog = false
                editingStudent = null
            },
            onRequestSave = { studentData ->
                if (editingStudent != null) {
                    val ok = onUpdateStudent(studentData)
                    if (ok) {
                        Toast.makeText(context, "اطلاعات ${studentData.name} با موفقیت ویرایش شد.", Toast.LENGTH_SHORT).show()
                        showAddStudentDialog = false
                        editingStudent = null
                    } else {
                        Toast.makeText(context, "خطا در ویرایش اطلاعات!", Toast.LENGTH_SHORT).show()
                    }
                } else {
                    val ok = onAddStudent(studentData)
                    if (ok) {
                        Toast.makeText(context, "دانش‌آموز «${studentData.name}» با موفقیت افزوده شد.", Toast.LENGTH_SHORT).show()
                        showAddStudentDialog = false
                        editingStudent = null
                    } else {
                        Toast.makeText(context, "خطا در افزودن دانش‌آموز (نام یا شماره شاد تکراری است)", Toast.LENGTH_LONG).show()
                    }
                }
            }
        )
    }

    // دیالوگ تأیید حذف دانش‌آموز
    studentToDelete?.let { student ->
        AlertDialog(
            onDismissRequest = { studentToDelete = null },
            icon = {
                Icon(
                    imageVector = Icons.Default.DeleteForever,
                    contentDescription = null,
                    tint = Color(0xFFDC2626),
                    modifier = Modifier.size(36.dp)
                )
            },
            title = {
                Text("حذف دانش‌آموز", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            },
            text = {
                Text(
                    text = "آیا از حذف دانش‌آموز «${student.name}» از کلاس مطمئن هستید؟ تمام اطلاعات فردی، نمرات و سوابق حضور و غیاب وی حذف خواهد شد.",
                    fontSize = 13.5.sp,
                    lineHeight = 22.sp,
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                Button(
                    onClick = {
                        onDeleteStudent(student.id)
                        studentToDelete = null
                        Toast.makeText(context, "دانش‌آموز «${student.name}» با موفقیت حذف شد.", Toast.LENGTH_SHORT).show()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626))
                ) {
                    Text("بله، حذف شود", fontWeight = FontWeight.Bold, color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { studentToDelete = null }) {
                    Text("انصراف")
                }
            }
        )
    }

    // دیالوگ اعلام قفل سقف ۱۰ دانش‌آموز در نسخه دمو
    if (showDemoLimitDialog) {
        AlertDialog(
            onDismissRequest = { showDemoLimitDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "قفل نسخه دمو",
                    tint = Color(0xFFD97706),
                    modifier = Modifier.size(40.dp)
                )
            },
            title = {
                Text("نسخه دمو (آزمایشی)", fontWeight = FontWeight.Bold, textAlign = TextAlign.Center)
            },
            text = {
                Text(
                    text = DemoConfig.DEMO_LIMIT_ERROR_MESSAGE,
                    fontSize = 13.5.sp,
                    lineHeight = 22.sp,
                    textAlign = TextAlign.Center
                )
            },
            confirmButton = {
                if (onNavigateToPro != null) {
                    Button(
                        onClick = {
                            showDemoLimitDialog = false
                            onNavigateToPro()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
                    ) {
                        Text("ارتقا به نسخه پرو", fontWeight = FontWeight.Bold)
                    }
                }
            },
            dismissButton = {
                TextButton(onClick = { showDemoLimitDialog = false }) {
                    Text("متوجه شدم")
                }
            }
        )
    }
}
