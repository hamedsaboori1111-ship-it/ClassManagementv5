package com.example.ui.screens

import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.SubjectBudgeting
import com.example.model.SubjectItem
import com.example.ui.theme.*
import com.example.util.DateUtils

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CurriculumBudgetingScreen(
    subjects: List<SubjectItem>,
    budgetings: List<SubjectBudgeting>,
    currentDate: String,
    onBack: () -> Unit,
    onSaveBudgeting: (List<SubjectBudgeting>) -> Unit
) {
    BackHandler { onBack() }

    val context = LocalContext.current

    // ماه‌های سال تحصیلی ایران (شروع از مهر تا پایان سال)
    val academicMonths = remember {
        listOf(
            "مهر", "آبان", "آذر",
            "دی", "بهمن", "اسفند",
            "فروردین", "اردیبهشت", "خرداد",
            "تیر", "مرداد", "شهریور"
        )
    }

    // تشخیص ماه جاری بر اساس تاریخ شمسی برنامه جهت انتخاب اولیه
    val todayParsed = remember(currentDate) { DateUtils.parseJalali(currentDate) }
    val currentAcademicMonth = todayParsed?.monthName ?: "مهر"

    var selectedMonth by remember {
        mutableStateOf(if (currentAcademicMonth in academicMonths) currentAcademicMonth else "مهر")
    }

    // فقط دروس فعال نمایش داده شوند
    val activeSubjects = remember(subjects) {
        subjects.filter { it.enabled }
    }

    // نگهداری موقت صفحات وارد شده برای نیمه اول و نیمه دوم دروس در ماه انتخابی
    // کلید: subjectId -> Pair(firstHalfPage, secondHalfPage)
    var currentMonthInputs by remember {
        mutableStateOf<Map<Long, Pair<String, String>>>(emptyMap())
    }

    // بارگذاری مقادیر ذخیره شده هنگام تغییر ماه یا تغییر لیست بودجه‌بندی‌ها
    LaunchedEffect(selectedMonth, budgetings, activeSubjects) {
        val map = mutableMapOf<Long, Pair<String, String>>()
        activeSubjects.forEach { sub ->
            val existing = budgetings.find { it.subjectId == sub.id && it.monthName == selectedMonth }
            val first = existing?.firstHalfPage ?: ""
            val second = existing?.secondHalfPage ?: ""
            map[sub.id] = Pair(first, second)
        }
        currentMonthInputs = map
    }

    // تابع ذخیره بودجه‌بندی ماه جاری
    val handleSave = {
        val updatedItems = activeSubjects.map { sub ->
            val pages = currentMonthInputs[sub.id] ?: Pair("", "")
            SubjectBudgeting(
                subjectId = sub.id,
                monthName = selectedMonth,
                firstHalfPage = pages.first.trim(),
                secondHalfPage = pages.second.trim()
            )
        }
        onSaveBudgeting(updatedItems)
        Toast.makeText(
            context,
            "بودجه‌بندی ماه «$selectedMonth» با موفقیت ذخیره شد.",
            Toast.LENGTH_SHORT
        ).show()
    }

    // محاسبه آمار مقایسه‌ای کلی ماه برای نوار بالا
    val plannedCount = remember(currentMonthInputs, activeSubjects) {
        activeSubjects.count { sub ->
            val p = currentMonthInputs[sub.id] ?: Pair("", "")
            p.first.isNotBlank() || p.second.isNotBlank()
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "بودجه‌بندی دروس",
                            fontWeight = FontWeight.Bold,
                            color = Color.White,
                            fontSize = 18.sp
                        )
                    }
                },
                navigationIcon = {
                    IconButton(onClick = onBack) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "بازگشت",
                            tint = Color.White
                        )
                    }
                },
                actions = {
                    Button(
                        onClick = handleSave,
                        colors = ButtonDefaults.buttonColors(
                            containerColor = Color.White,
                            contentColor = PrimaryGreenDark
                        ),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        modifier = Modifier
                            .padding(end = 8.dp)
                            .testTag("budgeting_top_save_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "ذخیره",
                            fontWeight = FontWeight.Bold,
                            fontSize = 13.sp
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = PrimaryGreen)
            )
        },
        floatingActionButton = {
            ExtendedFloatingActionButton(
                onClick = handleSave,
                containerColor = PrimaryGreen,
                contentColor = Color.White,
                icon = { Icon(Icons.Default.Save, contentDescription = null) },
                text = { Text("ذخیره بودجه‌بندی $selectedMonth", fontWeight = FontWeight.Bold) },
                modifier = Modifier.testTag("budgeting_fab_save")
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(BackgroundLight)
        ) {
            // ۱. نوار تب اسکرول‌پذیر انتخاب ماه در بالای صفحه
            Surface(
                modifier = Modifier.fillMaxWidth(),
                color = Color.White,
                shadowElevation = 2.dp
            ) {
                Column {
                    ScrollableTabRow(
                        selectedTabIndex = academicMonths.indexOf(selectedMonth).coerceAtLeast(0),
                        edgePadding = 12.dp,
                        containerColor = Color.White,
                        contentColor = PrimaryGreen,
                        divider = {}
                    ) {
                        academicMonths.forEach { month ->
                            val isSelected = (month == selectedMonth)
                            val isCurrentMonth = (month == currentAcademicMonth)
                            Tab(
                                selected = isSelected,
                                onClick = { selectedMonth = month },
                                text = {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = month,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                                            fontSize = if (isSelected) 14.sp else 13.sp,
                                            color = if (isSelected) PrimaryGreen else TextSecondary
                                        )
                                        if (isCurrentMonth) {
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Box(
                                                modifier = Modifier
                                                    .size(6.dp)
                                                    .clip(CircleShape)
                                                    .background(PrimaryGreen)
                                            )
                                        }
                                    }
                                },
                                modifier = Modifier.testTag("budgeting_tab_$month")
                            )
                        }
                    }

                    // نوار وضعیت کلی ماه: مقایسه دروس برنامه‌ریزی شده و راهنما
                    Surface(
                        color = Color(0xFFF8FAFC),
                        border = BorderStroke(0.8.dp, Color(0xFFE2E8F0)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 7.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.MenuBook,
                                    contentDescription = null,
                                    tint = PrimaryGreen,
                                    modifier = Modifier.size(16.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "بودجه‌بندی دروس: نیمه اول (۱ تا ۱۵) و نیمه دوم (۱۶ تا آخر ماه)",
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF334155)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(10.dp),
                                color = if (plannedCount == activeSubjects.size && activeSubjects.isNotEmpty()) {
                                    Color(0xFFDCFCE7)
                                } else {
                                    Color(0xFFFEF3C7)
                                }
                            ) {
                                Text(
                                    text = "${DateUtils.toPersianDigits(plannedCount)} از ${DateUtils.toPersianDigits(activeSubjects.size)} درس",
                                    fontSize = 10.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (plannedCount == activeSubjects.size && activeSubjects.isNotEmpty()) {
                                        Color(0xFF15803D)
                                    } else {
                                        Color(0xFFB45309)
                                    },
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }

            // ۲. لیست دروس فعال کلاسی با طراحی فشرده و بهینه (کاهش ارتفاع به نصف و حذف فلش)
            if (activeSubjects.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(
                            imageVector = Icons.Default.MenuBook,
                            contentDescription = null,
                            tint = Color.LightGray,
                            modifier = Modifier.size(64.dp)
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "هیچ درس فعالی یافت نشد.",
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "برای بودجه‌بندی، لطفاً از بخش «مدیریت دروس» حداقل یک درس را فعال کنید.",
                            fontSize = 12.sp,
                            color = TextSecondary
                        )
                    }
                }
            } else {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(activeSubjects, key = { it.id }) { subject ->
                        val pages = currentMonthInputs[subject.id] ?: Pair("", "")
                        val isComplete = pages.first.isNotBlank() && pages.second.isNotBlank()
                        val isPartial = (pages.first.isNotBlank() || pages.second.isNotBlank()) && !isComplete

                        // کارت فشرده برای هر درس (ارتفاع حدود نصف اندازه قبل و بدون تصویر فلش)
                        Card(
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = Color.White),
                            border = BorderStroke(
                                1.dp,
                                if (isComplete) PrimaryGreen.copy(alpha = 0.5f) else Color(0xFFE2E8F0)
                            ),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("budgeting_card_${subject.id}")
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp)
                            ) {
                                // ۱. سربرگ کارت: نام درس، آیکون و وضعیت ثبت
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Box(
                                            modifier = Modifier
                                                .size(28.dp)
                                                .background(PrimaryGreen.copy(alpha = 0.12f), CircleShape),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Book,
                                                contentDescription = null,
                                                tint = PrimaryGreen,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(
                                            text = subject.name,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 14.5.sp,
                                            color = TextPrimary
                                        )
                                    }

                                    // برچسب کوچک وضعیت ثبت
                                    Surface(
                                        shape = RoundedCornerShape(6.dp),
                                        color = when {
                                            isComplete -> Color(0xFFDCFCE7)
                                            isPartial -> Color(0xFFFEF3C7)
                                            else -> Color(0xFFF1F5F9)
                                        },
                                        border = BorderStroke(
                                            0.8.dp,
                                            when {
                                                isComplete -> Color(0xFF86EFAC)
                                                isPartial -> Color(0xFFFDE68A)
                                                else -> Color(0xFFCBD5E1)
                                            }
                                        )
                                    ) {
                                        Row(
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Icon(
                                                imageVector = when {
                                                    isComplete -> Icons.Default.CheckCircle
                                                    isPartial -> Icons.Default.Pending
                                                    else -> Icons.Default.RadioButtonUnchecked
                                                },
                                                contentDescription = null,
                                                tint = when {
                                                    isComplete -> Color(0xFF16A34A)
                                                    isPartial -> Color(0xFFD97706)
                                                    else -> Color(0xFF94A3B8)
                                                },
                                                modifier = Modifier.size(11.dp)
                                            )
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text(
                                                text = when {
                                                    isComplete -> "ثبت کامل"
                                                    isPartial -> "نیمه‌کاره"
                                                    else -> "ثبت‌نشده"
                                                },
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = when {
                                                    isComplete -> Color(0xFF15803D)
                                                    isPartial -> Color(0xFFB45309)
                                                    else -> Color(0xFF64748B)
                                                }
                                            )
                                        }
                                    }
                                }

                                Spacer(modifier = Modifier.height(7.dp))

                                // ۲. ورودی‌های دو نیمه ماه در کنار هم (بدون تصویر فلش و با ارتفاع بهینه)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // بخش ۱: نیمه اول ماه (روز ۱ تا ۱۵)
                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(Color(0xFFF0FDF4), RoundedCornerShape(8.dp))
                                            .border(1.dp, Color(0xFFBBF7D0), RoundedCornerShape(8.dp))
                                            .padding(horizontal = 8.dp, vertical = 6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "نیمه اول (۱ تا ۱۵)",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = PrimaryGreenDark
                                            )
                                            if (pages.first.isNotBlank()) {
                                                IconButton(
                                                    onClick = {
                                                        currentMonthInputs = currentMonthInputs.toMutableMap().apply {
                                                            put(subject.id, Pair("", pages.second))
                                                        }
                                                    },
                                                    modifier = Modifier.size(18.dp)
                                                ) {
                                                    Icon(
                                                        Icons.Default.Clear,
                                                        contentDescription = "پاک کردن",
                                                        tint = Color.Gray,
                                                        modifier = Modifier.size(12.dp)
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))

                                        OutlinedTextField(
                                            value = pages.first,
                                            onValueChange = { input ->
                                                val sanitized = DateUtils.toPersianDigits(input.filter { it.isDigit() || it in '۰'..'۹' })
                                                currentMonthInputs = currentMonthInputs.toMutableMap().apply {
                                                    put(subject.id, Pair(sanitized, pages.second))
                                                }
                                            },
                                            placeholder = {
                                                Text(
                                                    "تا صفحه...",
                                                    fontSize = 11.sp,
                                                    color = Color.LightGray
                                                )
                                            },
                                            singleLine = true,
                                            textStyle = LocalTextStyle.current.copy(
                                                fontSize = 12.5.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                textAlign = TextAlign.Center
                                            ),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(46.dp)
                                                .testTag("budgeting_input_first_${subject.id}"),
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = PrimaryGreen,
                                                unfocusedBorderColor = Color(0xFF86EFAC),
                                                focusedContainerColor = Color.White,
                                                unfocusedContainerColor = Color.White
                                            )
                                        )
                                    }

                                    // بخش ۲: نیمه دوم ماه (روز ۱۶ تا پایان ماه)
                                    Column(
                                        modifier = Modifier
                                            .weight(1f)
                                            .background(Color(0xFFFFFBEB), RoundedCornerShape(8.dp))
                                            .border(1.dp, Color(0xFFFDE68A), RoundedCornerShape(8.dp))
                                            .padding(horizontal = 8.dp, vertical = 6.dp)
                                    ) {
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween,
                                            verticalAlignment = Alignment.CenterVertically
                                        ) {
                                            Text(
                                                text = "نیمه دوم (۱۶ تا آخر)",
                                                fontSize = 11.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = Color(0xFFB45309)
                                            )
                                            if (pages.second.isNotBlank()) {
                                                IconButton(
                                                    onClick = {
                                                        currentMonthInputs = currentMonthInputs.toMutableMap().apply {
                                                            put(subject.id, Pair(pages.first, ""))
                                                        }
                                                    },
                                                    modifier = Modifier.size(18.dp)
                                                ) {
                                                    Icon(
                                                        Icons.Default.Clear,
                                                        contentDescription = "پاک کردن",
                                                        tint = Color.Gray,
                                                        modifier = Modifier.size(12.dp)
                                                    )
                                                }
                                            }
                                        }

                                        Spacer(modifier = Modifier.height(4.dp))

                                        OutlinedTextField(
                                            value = pages.second,
                                            onValueChange = { input ->
                                                val sanitized = DateUtils.toPersianDigits(input.filter { it.isDigit() || it in '۰'..'۹' })
                                                currentMonthInputs = currentMonthInputs.toMutableMap().apply {
                                                    put(subject.id, Pair(pages.first, sanitized))
                                                }
                                            },
                                            placeholder = {
                                                Text(
                                                    "تا صفحه...",
                                                    fontSize = 11.sp,
                                                    color = Color.LightGray
                                                )
                                            },
                                            singleLine = true,
                                            textStyle = LocalTextStyle.current.copy(
                                                fontSize = 12.5.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                textAlign = TextAlign.Center
                                            ),
                                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                            modifier = Modifier
                                                .fillMaxWidth()
                                                .height(46.dp)
                                                .testTag("budgeting_input_second_${subject.id}"),
                                            colors = OutlinedTextFieldDefaults.colors(
                                                focusedBorderColor = Color(0xFFD97706),
                                                unfocusedBorderColor = Color(0xFFFCD34D),
                                                focusedContainerColor = Color.White,
                                                unfocusedContainerColor = Color.White
                                            )
                                        )
                                    }
                                }
                            }
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(84.dp))
                    }
                }
            }
        }
    }
}
