package com.example.ui.screens

import android.app.Activity
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Pin
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import com.example.security.BiometricAvailability
import com.example.security.SecurityManager
import com.example.security.SecurityType
import com.example.ui.components.PatternLockView
import com.example.ui.components.PinKeypadView
import com.example.ui.theme.BackgroundLight
import com.example.ui.theme.PrimaryGreen
import kotlinx.coroutines.delay

@Composable
fun AppLockScreen(
    teacherName: String,
    schoolName: String,
    onUnlock: () -> Unit
) {
    val context = LocalContext.current
    val activity = context as? FragmentActivity

    // خروج کامل از برنامه در صورت زدن دکمه بازگشت در صفحه قفل
    BackHandler(enabled = true) {
        activity?.finishAffinity()
        activity?.finishAndRemoveTask()
    }

    val securityType = remember { SecurityManager.getSecurityType(context) }
    var activeMode by remember { mutableStateOf(securityType) }

    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    var patternError by remember { mutableStateOf(false) }
    var patternSuccess by remember { mutableStateOf(false) }

    var biometricMessage by remember { mutableStateOf("جهت ورود، انگشت خود را روی حسگر قرار دهید") }

    // Helper to launch biometric prompt
    val launchBiometricPrompt: () -> Unit = {
        if (activity != null) {
            val executor = ContextCompat.getMainExecutor(context)
            val biometricPrompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
                override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                    super.onAuthenticationSucceeded(result)
                    SecurityManager.vibrate(context, 35)
                    onUnlock()
                }

                override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                    super.onAuthenticationError(errorCode, errString)
                    biometricMessage = "خطا در تأیید هویت: $errString"
                }

                override fun onAuthenticationFailed() {
                    super.onAuthenticationFailed()
                    SecurityManager.vibrate(context, 80)
                    biometricMessage = "اثر انگشت شناسایی نشد، لطفاً مجدداً امتحان کنید"
                }
            })

            val promptInfo = BiometricPrompt.PromptInfo.Builder()
                .setTitle("ورود به دفتر مدیریت کلاسی")
                .setSubtitle("احراز هویت معلم")
                .setDescription("لطفاً انگشت خود را روی سنسور اثر انگشت گوشی قرار دهید")
                .setNegativeButtonText(
                    if (SecurityManager.getPin(context).isNotBlank()) "ورود با رمز عبور" else "انصراف"
                )
                .build()

            try {
                biometricPrompt.authenticate(promptInfo)
            } catch (e: Exception) {
                biometricMessage = "خطا در فعال‌سازی حسگر: ${e.message}"
            }
        }
    }

    // Auto trigger biometric on start if in FINGERPRINT mode
    LaunchedEffect(activeMode) {
        if (activeMode == SecurityType.FINGERPRINT) {
            delay(300)
            launchBiometricPrompt()
        }
    }

    // Handle PIN input completion
    LaunchedEffect(enteredPin) {
        val requiredLength = SecurityManager.getPin(context).length.coerceAtLeast(4)
        if (enteredPin.length >= requiredLength) {
            if (SecurityManager.verifyPin(context, enteredPin)) {
                SecurityManager.vibrate(context, 30)
                onUnlock()
            } else {
                pinError = true
                SecurityManager.vibrate(context, 90)
                delay(700)
                enteredPin = ""
                pinError = false
            }
        }
    }

    // Pulsing animation for fingerprint icon
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = 1.08f,
        animationSpec = infiniteRepeatable(
            animation = tween(1000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "scale"
    )

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = BackgroundLight
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            // Header info
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(top = 28.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(76.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(
                                colors = listOf(PrimaryGreen, PrimaryGreen.copy(alpha = 0.8f))
                            )
                        ),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = when (activeMode) {
                            SecurityType.PIN -> Icons.Default.Lock
                            SecurityType.PATTERN -> Icons.Default.Security
                            SecurityType.FINGERPRINT -> Icons.Default.Fingerprint
                            else -> Icons.Default.Lock
                        },
                        contentDescription = "قفل برنامه",
                        tint = Color.White,
                        modifier = Modifier.size(40.dp)
                    )
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(
                    text = "دفتر مدیریت کلاسی",
                    style = MaterialTheme.typography.headlineSmall,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF0F172A)
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = if (teacherName.isNotBlank()) "خوش آمدید، $teacherName" else "ورود امن آموزگار",
                    fontSize = 14.sp,
                    color = Color(0xFF64748B),
                    fontWeight = FontWeight.Medium
                )

                if (schoolName.isNotBlank()) {
                    Text(
                        text = schoolName,
                        fontSize = 12.sp,
                        color = Color(0xFF94A3B8)
                    )
                }
            }

            // Central interactive lock area
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth(),
                contentAlignment = Alignment.Center
            ) {
                when (activeMode) {
                    SecurityType.PIN -> {
                        val pinLen = SecurityManager.getPin(context).length.coerceAtLeast(4)
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = if (pinError) "رمز عبور نادرست است" else "رمز عبور خود را وارد کنید",
                                color = if (pinError) Color(0xFFEF4444) else Color(0xFF334155),
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            PinKeypadView(
                                pinLength = pinLen,
                                currentLength = enteredPin.length,
                                isError = pinError,
                                onDigitClick = { digit ->
                                    if (enteredPin.length < pinLen) {
                                        enteredPin += digit
                                    }
                                },
                                onBackspaceClick = {
                                    if (enteredPin.isNotEmpty()) {
                                        enteredPin = enteredPin.dropLast(1)
                                    }
                                },
                                onClearClick = {
                                    enteredPin = ""
                                }
                            )
                        }
                    }

                    SecurityType.PATTERN -> {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = when {
                                    patternError -> "الگوی ترسیم شده اشتباه است"
                                    patternSuccess -> "الگو تأیید شد"
                                    else -> "الگوی امنیتی را رسم کنید"
                                },
                                color = when {
                                    patternError -> Color(0xFFEF4444)
                                    patternSuccess -> Color(0xFF10B981)
                                    else -> Color(0xFF334155)
                                },
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 15.sp
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            PatternLockView(
                                modifier = Modifier
                                    .fillMaxWidth(0.85f)
                                    .aspectRatio(1f),
                                isError = patternError,
                                isSuccess = patternSuccess,
                                onPatternCompleted = { pattern ->
                                    if (SecurityManager.verifyPattern(context, pattern)) {
                                        patternSuccess = true
                                        onUnlock()
                                    } else {
                                        patternError = true
                                    }
                                }
                            )
                        }
                    }

                    SecurityType.FINGERPRINT -> {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            modifier = Modifier.padding(16.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(110.dp)
                                    .scale(pulseScale)
                                    .clip(CircleShape)
                                    .background(PrimaryGreen.copy(alpha = 0.12f))
                                    .clickable { launchBiometricPrompt() },
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Fingerprint,
                                    contentDescription = "حسگر اثر انگشت",
                                    tint = PrimaryGreen,
                                    modifier = Modifier.size(64.dp)
                                )
                            }

                            Spacer(modifier = Modifier.height(20.dp))

                            Text(
                                text = "احراز هویت با اثر انگشت",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF0F172A)
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text(
                                text = biometricMessage,
                                fontSize = 13.sp,
                                color = Color(0xFF64748B),
                                textAlign = TextAlign.Center,
                                modifier = Modifier.padding(horizontal = 20.dp)
                            )

                            Spacer(modifier = Modifier.height(24.dp))

                            Button(
                                onClick = { launchBiometricPrompt() },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Icon(imageVector = Icons.Default.Fingerprint, contentDescription = null)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("لمس مجدد حسگر اثر انگشت", fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    SecurityType.NONE -> {
                        LaunchedEffect(Unit) { onUnlock() }
                    }
                }
            }

            // Fallback buttons (if user has another mode available)
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier.padding(bottom = 12.dp)
            ) {
                if (activeMode == SecurityType.FINGERPRINT && SecurityManager.getPin(context).isNotBlank()) {
                    TextButton(onClick = { activeMode = SecurityType.PIN }) {
                        Text("ورود با رمز عبور (PIN)", color = PrimaryGreen, fontWeight = FontWeight.SemiBold)
                    }
                } else if (activeMode == SecurityType.FINGERPRINT && SecurityManager.getPattern(context).isNotEmpty()) {
                    TextButton(onClick = { activeMode = SecurityType.PATTERN }) {
                        Text("ورود با الگوی تصویری", color = PrimaryGreen, fontWeight = FontWeight.SemiBold)
                    }
                } else if (activeMode != securityType && securityType == SecurityType.FINGERPRINT) {
                    TextButton(onClick = { activeMode = SecurityType.FINGERPRINT }) {
                        Text("بازگشت به ورود با اثر انگشت", color = PrimaryGreen, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }
    }
}
