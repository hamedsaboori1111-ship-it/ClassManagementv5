package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.Student
import com.example.ui.theme.*

/**
 * فرم جامع ثبت و ویرایش دانش‌آموز با تمام فیلدهای شناسنامه‌ای و خانوادگی
 */
@Composable
fun StudentFormDialog(
    initialStudent: Student?,
    existingStudents: List<Student>,
    onDismiss: () -> Unit,
    onRequestSave: (Student) -> Unit
) {
    var name by remember { mutableStateOf(initialStudent?.name ?: "") }
    var shad by remember { mutableStateOf(initialStudent?.shad ?: "") }
    var birthDate by remember { mutableStateOf(initialStudent?.birthDate ?: "") }
    var birthPlace by remember { mutableStateOf(initialStudent?.birthPlace ?: "") }

    var fatherName by remember { mutableStateOf(initialStudent?.fatherName ?: "") }
    var fatherBirthDate by remember { mutableStateOf(initialStudent?.fatherBirthDate ?: "") }
    var fatherJob by remember { mutableStateOf(initialStudent?.fatherJob ?: "") }
    var fatherEducation by remember { mutableStateOf(initialStudent?.fatherEducation ?: "") }

    var motherName by remember { mutableStateOf(initialStudent?.motherName ?: "") }
    var motherBirthDate by remember { mutableStateOf(initialStudent?.motherBirthDate ?: "") }
    var motherJob by remember { mutableStateOf(initialStudent?.motherJob ?: "") }
    var motherEducation by remember { mutableStateOf(initialStudent?.motherEducation ?: "") }

    var photoUri by remember { mutableStateOf(initialStudent?.photoUri ?: "") }
    var notes by remember { mutableStateOf(initialStudent?.notes ?: "") }

    var errorMessage by remember { mutableStateOf<String?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        com.example.security.SecurityManager.clearBypass()
        if (uri != null) {
            photoUri = uri.toString()
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Text(
                text = if (initialStudent != null) "ویرایش اطلاعات دانش‌آموز" else "ثبت اطلاعات دانش‌آموز جدید",
                fontWeight = FontWeight.Bold,
                fontSize = 16.sp
            )
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // نمایش پیام خطای اعتبارسنجی
                errorMessage?.let { msg ->
                    Surface(
                        color = Color(0xFFFEE2E2),
                        border = BorderStroke(1.dp, Color(0xFFFCA5A5)),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = Color(0xFFDC2626), modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(msg, color = Color(0xFFB91C1C), fontSize = 12.sp)
                        }
                    }
                }

                // ۱. تصویر دانش‌آموز
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (photoUri.isNotBlank()) {
                            AsyncImage(
                                model = photoUri,
                                contentDescription = "عکس دانش‌آموز",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(CircleShape)
                                    .background(Color.LightGray)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(60.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFE2E8F0)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(32.dp))
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Button(
                                onClick = {
                                    com.example.security.SecurityManager.setTemporaryPickerBypass()
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.AddPhotoAlternate, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(if (photoUri.isNotBlank()) "تغییر عکس" else "انتخاب عکس", fontSize = 12.sp)
                            }

                            if (photoUri.isNotBlank()) {
                                TextButton(
                                    onClick = { photoUri = "" },
                                    colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFDC2626)),
                                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 0.dp)
                                ) {
                                    Text("حذف عکس", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }

                // ۲. مشخصات فردی دانش‌آموز
                Text("مشخصات فردی دانش‌آموز:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = PrimaryGreenDark)

                OutlinedTextField(
                    value = name,
                    onValueChange = {
                        name = it
                        errorMessage = null
                    },
                    label = { Text("نام و نام خانوادگی * (اجباری)") },
                    singleLine = true,
                    isError = name.isBlank() && errorMessage != null,
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = shad,
                    onValueChange = {
                        shad = it
                        errorMessage = null
                    },
                    label = { Text("شماره شاد * (اجباری)") },
                    singleLine = true,
                    isError = shad.isBlank() && errorMessage != null,
                    modifier = Modifier.fillMaxWidth()
                )

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    PersianDateField(
                        value = birthDate,
                        onDateSelected = { birthDate = it },
                        label = "تاریخ تولد",
                        placeholder = "انتخاب از تقویم...",
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = birthPlace,
                        onValueChange = { birthPlace = it },
                        label = { Text("محل تولد") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // ۳. مشخصات پدر
                Spacer(modifier = Modifier.height(4.dp))
                Text("مشخصات پدر:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0369A1))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = fatherName,
                        onValueChange = { fatherName = it },
                        label = { Text("نام پدر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    PersianDateField(
                        value = fatherBirthDate,
                        onDateSelected = { fatherBirthDate = it },
                        label = "تاریخ تولد پدر",
                        placeholder = "انتخاب از تقویم...",
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = fatherJob,
                        onValueChange = { fatherJob = it },
                        label = { Text("شغل پدر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = fatherEducation,
                        onValueChange = { fatherEducation = it },
                        label = { Text("تحصیلات پدر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // ۴. مشخصات مادر
                Spacer(modifier = Modifier.height(4.dp))
                Text("مشخصات مادر:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF9333EA))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = motherName,
                        onValueChange = { motherName = it },
                        label = { Text("نام مادر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    PersianDateField(
                        value = motherBirthDate,
                        onDateSelected = { motherBirthDate = it },
                        label = "تاریخ تولد مادر",
                        placeholder = "انتخاب از تقویم...",
                        modifier = Modifier.weight(1f)
                    )
                }

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = motherJob,
                        onValueChange = { motherJob = it },
                        label = { Text("شغل مادر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = motherEducation,
                        onValueChange = { motherEducation = it },
                        label = { Text("تحصیلات مادر") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                }

                // ۵. سایر توضیحات
                Spacer(modifier = Modifier.height(4.dp))
                Text("سایر توضیحات:", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color(0xFF0284C7))
                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("سایر توضیحات (نکات مهم و اختصاصی)") },
                    placeholder = { Text("توضیحات و نکات مهم در خصوص وضعیت تحصیلی، پزشکی، رفتاری یا خانوادگی دانش‌آموز...") },
                    minLines = 2,
                    maxLines = 4,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val trimmedName = name.trim()
                    val trimmedShad = shad.trim()

                    if (trimmedName.isBlank()) {
                        errorMessage = "نام و نام خانوادگی اجباری است."
                        return@Button
                    }
                    if (trimmedShad.isBlank()) {
                        errorMessage = "شماره شاد اجباری است."
                        return@Button
                    }

                    val isDuplicate = existingStudents.any { other ->
                        val isSameStudent = initialStudent != null && other.id == initialStudent.id
                        !isSameStudent && (
                            other.name.trim().equals(trimmedName, ignoreCase = true) ||
                            (other.shad.isNotBlank() && other.shad.trim() == trimmedShad)
                        )
                    }

                    if (isDuplicate) {
                        errorMessage = "دانش‌آموزی با این نام یا شماره شاد قبلاً در کلاس ثبت شده است و امکان ثبت تکراری وجود ندارد!"
                        return@Button
                    }

                    val updatedOrNew = Student(
                        id = initialStudent?.id ?: System.currentTimeMillis(),
                        name = trimmedName,
                        status = initialStudent?.status ?: "حاضر",
                        shad = trimmedShad,
                        birthDate = birthDate.trim(),
                        birthPlace = birthPlace.trim(),
                        fatherName = fatherName.trim(),
                        fatherBirthDate = fatherBirthDate.trim(),
                        fatherJob = fatherJob.trim(),
                        fatherEducation = fatherEducation.trim(),
                        motherName = motherName.trim(),
                        motherBirthDate = motherBirthDate.trim(),
                        motherJob = motherJob.trim(),
                        motherEducation = motherEducation.trim(),
                        photoUri = photoUri,
                        birthMonth = if (birthDate.isNotBlank() && birthDate.trim() != "ثبت نشده") {
                            com.example.util.DateUtils.getStudentBirthMonth(birthDate.trim()) ?: ""
                        } else "",
                        notes = notes.trim(),
                        evaluations = initialStudent?.evaluations ?: emptyList()
                    )

                    onRequestSave(updatedOrNew)
                },
                colors = ButtonDefaults.buttonColors(containerColor = PrimaryGreen)
            ) {
                Text(if (initialStudent != null) "ثبت تغییرات" else "ثبت دانش‌آموز", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("انصراف")
            }
        }
    )
}

/**
 * دیالوگ شناسنامه کامل دانش‌آموز با نمایش عکس، مشخصات شناسنامه‌ای و اطلاعات والدین
 */
@Composable
fun StudentProfileDetailDialog(
    student: Student,
    onDismiss: () -> Unit,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("شناسنامه دانش‌آموز", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "بستن")
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // کارت سربرگ مشخصات دانش‌آموز با عکس
                Card(
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, Color(0xFFBBF7D0)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (student.photoUri.isNotBlank()) {
                            AsyncImage(
                                model = student.photoUri,
                                contentDescription = "عکس ${student.name}",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(Color.LightGray)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .size(64.dp)
                                    .clip(CircleShape)
                                    .background(PrimaryGreen.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text(
                                    text = student.name.take(1),
                                    fontSize = 24.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = PrimaryGreenDark
                                )
                            }
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = student.name,
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp,
                                color = TextPrimary
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "شماره شاد: ${student.shad.ifBlank { "ثبت نشده" }}",
                                fontSize = 12.sp,
                                color = TextSecondary
                            )
                            Text(
                                text = "وضعیت جاری: ${student.status}",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = when (student.status) {
                                    "حاضر" -> PrimaryGreenDark
                                    "غایب" -> Color(0xFFDC2626)
                                    "غیرموجه" -> Color(0xFFEA580C)
                                    else -> Color(0xFF0284C7)
                                }
                            )
                        }
                    }
                }

                // مشخصات فردی
                InfoSectionCard(title = "اطلاعات شناسنامه‌ای دانش‌آموز", icon = Icons.Default.Badge, tint = PrimaryGreenDark) {
                    InfoRow(label = "تاریخ تولد:", value = student.birthDate.ifBlank { "ثبت نشده" })
                    InfoRow(label = "محل تولد:", value = student.birthPlace.ifBlank { "ثبت نشده" })
                }

                // مشخصات پدر
                InfoSectionCard(title = "مشخصات پدر", icon = Icons.Default.Person, tint = Color(0xFF0369A1)) {
                    InfoRow(label = "نام پدر:", value = student.fatherName.ifBlank { "ثبت نشده" })
                    InfoRow(label = "تاریخ تولد پدر:", value = student.fatherBirthDate.ifBlank { "ثبت نشده" })
                    InfoRow(label = "شغل پدر:", value = student.fatherJob.ifBlank { "ثبت نشده" })
                    InfoRow(label = "تحصیلات پدر:", value = student.fatherEducation.ifBlank { "ثبت نشده" })
                }

                // مشخصات مادر
                InfoSectionCard(title = "مشخصات مادر", icon = Icons.Default.PersonOutline, tint = Color(0xFF9333EA)) {
                    InfoRow(label = "نام مادر:", value = student.motherName.ifBlank { "ثبت نشده" })
                    InfoRow(label = "تاریخ تولد مادر:", value = student.motherBirthDate.ifBlank { "ثبت نشده" })
                    InfoRow(label = "شغل مادر:", value = student.motherJob.ifBlank { "ثبت نشده" })
                    InfoRow(label = "تحصیلات مادر:", value = student.motherEducation.ifBlank { "ثبت نشده" })
                }

                // سایر توضیحات و نکات مهم
                if (student.notes.isNotBlank()) {
                    InfoSectionCard(title = "سایر توضیحات و نکات مهم", icon = Icons.Default.Description, tint = Color(0xFF0284C7)) {
                        Text(
                            text = student.notes,
                            fontSize = 13.sp,
                            lineHeight = 20.sp,
                            color = TextPrimary,
                            modifier = Modifier.padding(vertical = 4.dp)
                        )
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = onEdit,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0284C7))
            ) {
                Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("ویرایش مشخصات")
            }
        },
        dismissButton = {
            TextButton(
                onClick = onDelete,
                colors = ButtonDefaults.textButtonColors(contentColor = Color(0xFFDC2626))
            ) {
                Icon(Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text("حذف دانش‌آموز")
            }
        }
    )
}

@Composable
fun InfoSectionCard(
    title: String,
    icon: ImageVector,
    tint: Color,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFFF8FAFC)),
        border = BorderStroke(0.5.dp, BorderLight),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = tint)
            }
            Spacer(modifier = Modifier.height(6.dp))
            content()
        }
    }
}

@Composable
fun InfoRow(label: String, value: String) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(text = label, fontSize = 12.sp, color = TextSecondary)
        Text(text = value, fontSize = 12.sp, fontWeight = FontWeight.Medium, color = TextPrimary)
    }
}
