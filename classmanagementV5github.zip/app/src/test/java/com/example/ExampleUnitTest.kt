package com.example

import com.example.model.Student
import com.example.util.DateUtils
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testDateUtils_PersianDigits() {
    val englishDigits = "1403/07/15"
    val persianDigits = DateUtils.toPersianDigits(englishDigits)
    assertEquals("۱۴۰۳/۰۷/۱۵", persianDigits)
    assertEquals("1403/07/15", DateUtils.toEnglishDigits(persianDigits))
  }

  @Test
  fun testStudentBirthMonthDetection() {
    val s1 = Student(id = 1, name = "علی حسینی", birthDate = "۱۳۹۴/۰۷/۱۰", birthMonth = "مهر")
    val s2 = Student(id = 2, name = "رضا محمدی", birthDate = "۱۳۹۴/۰۸/۲۲", birthMonth = "آبان")

    val allPersianMonths = listOf(
      "فروردین", "اردیبهشت", "خرداد",
      "تیر", "مرداد", "شهریور",
      "مهر", "آبان", "آذر",
      "دی", "بهمن", "اسفند"
    )

    fun isStudentBornInTargetMonth(student: Student, targetMonth: String): Boolean {
      if (student.birthMonth.trim().equals(targetMonth.trim(), ignoreCase = true)) return true
      if (student.birthDate.isNotBlank()) {
        val eng = DateUtils.toEnglishDigits(student.birthDate)
        val parts = eng.split("/")
        if (parts.size >= 2) {
          val m = parts[1].toIntOrNull()
          if (m != null && m in 1..12) {
            if (allPersianMonths[m - 1] == targetMonth) return true
          }
        }
      }
      return false
    }

    assertTrue(isStudentBornInTargetMonth(s1, "مهر"))
    assertFalse(isStudentBornInTargetMonth(s1, "آبان"))
    assertTrue(isStudentBornInTargetMonth(s2, "آبان"))
    assertFalse(isStudentBornInTargetMonth(s2, "مهر"))
  }

  @Test
  fun testDemoConfigConstraints() {
    assertEquals(10, com.example.util.DemoConfig.MAX_STUDENTS_COUNT)
    assertTrue(com.example.util.DemoConfig.IS_DEMO_ENABLED)
    assertTrue(com.example.util.DemoConfig.getDrawerVersionText().contains("طراح حامد صبوری"))
    assertTrue(com.example.util.DemoConfig.getDrawerVersionText().contains("۱.۵") || com.example.util.DemoConfig.getDrawerVersionText().contains("1.5"))
    assertEquals("1.5", com.example.util.DemoConfig.APP_VERSION)
    assertTrue(com.example.util.DemoConfig.RUBIKA_CHANNEL_URL.contains("ClassManagement"))
    assertTrue(com.example.util.DemoConfig.DEMO_LIMIT_ERROR_MESSAGE.contains("ده نفر دانش‌آموز") || com.example.util.DemoConfig.DEMO_LIMIT_ERROR_MESSAGE.contains("ده دانش"))
    assertTrue(com.example.util.DemoConfig.DEMO_RESTORE_LOCKED_MESSAGE.contains("بازیابی فایل‌های پشتیبان"))
  }

  @Test
  fun testActivationKeyCalculation() {
    // فرمول: (((((((u×65)-230)÷27)+142)×4)-75)÷3)+39
    val key1 = com.example.util.ActivationManager.calculateActivationKey(123456L)
    assertEquals(6, key1.length)
    assertEquals("396470", key1)

    val key2 = com.example.util.ActivationManager.calculateActivationKey(523814L)
    assertEquals(6, key2.length)
    assertEquals("168157", key2)

    // بررسی تولید طول دقیق ۶ رقم
    for (code in listOf(100000L, 999999L, 500000L, 777777L)) {
      val key = com.example.util.ActivationManager.calculateActivationKey(code)
      assertEquals(6, key.length)
      assertTrue(key.all { it.isDigit() })
    }
  }

  @Test
  fun testTeacherNotesModelAndIdUniqueness() {
    val note1 = com.example.model.TeacherNote(id = 101L, title = "پیگیری درس ریاضی", content = "تمرینات فصل ۲ بررسی شود", date = "۱۴۰۳/۰۷/۱۰")
    val note2 = com.example.model.TeacherNote(id = 102L, title = "جلسه با والدین علی", content = "نیاز به تقویت املا دارد", date = "۱۴۰۳/۰۷/۱۵")

    assertEquals(101L, note1.id)
    assertEquals("پیگیری درس ریاضی", note1.title)
    assertEquals("تمرینات فصل ۲ بررسی شود", note1.content)
    assertEquals("۱۴۰۳/۰۷/۱۰", note1.date)

    assertNotEquals(note1.id, note2.id)
    val copied = note1.copy(id = 103L)
    assertEquals(103L, copied.id)
    assertEquals(note1.title, copied.title)
  }

  @Test
  fun testWeekendDaysRecognition() {
    assertTrue(DateUtils.isWeekendDay("پنجشنبه"))
    assertTrue(DateUtils.isWeekendDay("جمعه"))
    assertFalse(DateUtils.isWeekendDay("شنبه"))
    assertFalse(DateUtils.isWeekendDay("یکشنبه"))
    assertFalse(DateUtils.isWeekendDay("دوشنبه"))
    assertFalse(DateUtils.isWeekendDay("سه‌شنبه"))
    assertFalse(DateUtils.isWeekendDay("چهارشنبه"))
  }

  @Test
  fun testSubjectBudgetingModel() {
    val b1 = com.example.model.SubjectBudgeting(
      subjectId = 1L,
      monthName = "مهر",
      firstHalfPage = "۲۵",
      secondHalfPage = "۵۰"
    )
    assertEquals(1L, b1.subjectId)
    assertEquals("مهر", b1.monthName)
    assertEquals("۲۵", b1.firstHalfPage)
    assertEquals("۵۰", b1.secondHalfPage)

    val b2 = b1.copy(monthName = "آبان", firstHalfPage = "۷۵")
    assertEquals("آبان", b2.monthName)
    assertEquals("۷۵", b2.firstHalfPage)
    assertEquals("۵۰", b2.secondHalfPage)
  }

  @Test
  fun testBudgetingHalfMonthCalculation() {
    // روزهای ۱ تا ۱۵ نیمه اول، ۱۶ به بعد نیمه دوم
    for (day in 1..15) {
      assertTrue(day in 1..15)
    }
    for (day in 16..31) {
      assertFalse(day in 1..15)
    }
  }

  @Test
  fun testStudentReorderingLogic() {
    val s1 = com.example.model.Student(id = 1L, name = "علی محمدی")
    val s2 = com.example.model.Student(id = 2L, name = "رضا حسینی")
    val s3 = com.example.model.Student(id = 3L, name = "محمد کریمی")

    val initialList = listOf(s1, s2, s3)
    assertEquals("علی محمدی", initialList[0].name)

    // جابجایی دانش‌آموز اول با دوم
    val reordered = initialList.toMutableList()
    val moved = reordered.removeAt(0)
    reordered.add(1, moved)

    assertEquals(listOf(s2, s1, s3), reordered)
    assertEquals("رضا حسینی", reordered[0].name)
    assertEquals("علی محمدی", reordered[1].name)
    assertEquals("محمد کریمی", reordered[2].name)
  }
}


